package com.spring.esameJava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EsameJava4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
